#Aiden Allison
#3/28/24
#working with pandas
import pandas as pd
def display_menu():
    print(' MENU')
    print("1)Display Number of Students Registered in each class")
    print("2)Display the sum of tution collected for each class")
    print("3)Ask User if they wish to Delete Specific Col(s)")
    print("4)Save and Exit program")
    selectmenu = input("Menu choice:")
    return selectmenu
def cleanfile():
    basefile = pd.read_csv("m2_pro_data.csv")
    print(basefile)
    missing_values = basefile.loc[basefile['first_name'].isnull()]
    for index,row in missing_values.iterrows():
        fname = (basefile.iloc[[index -1]]["first_name"].to_string(index = False))
        lname = (basefile.iloc[[index -1]]["last_name"].to_string(index = False))
        basefile.loc[index,"first_name"] = fname
        basefile.loc[index,"last_name"] = lname
    print(basefile)
def main():
    file = cleanfile()
    menu = display_menu()
    while menu != "5":
        print(menu)
        if menu == "1":
            pass
        elif menu == "2":
            pass
        elif menu == "3":
            pass
        elif menu == "4":
            print("quitting program....")
        else:
            print("error no number to select menu")
        menu = display_menu()
if __name__ == "__main__":
        main()