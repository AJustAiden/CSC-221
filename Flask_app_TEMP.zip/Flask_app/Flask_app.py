from flask import *
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
app = Flask(__name__)
totalList = []
@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', title='Home')
@app.route('/history')
def history():
    return render_template('history.html', title='Past jobs', user= {'username': 'Miguel'})
@app.route('/daily')
def daily():
    return render_template('daily.html', title='Past jobs',)
@app.route("/Results",methods=["POST"])
def Results():
    ReviewT = request.form['ReviewT']
    NameT = request.form['NameT']
    Ratings = request.form['Ratings']
    Uname = request.form['Uname']
    sid_obj = SentimentIntensityAnalyzer()
    sentiment_dict = sid_obj.polarity_scores(Ratings)
    if sentiment_dict['neg']*100 > sentiment_dict['pos']*100:
        answer = "negative"
    else:
        answer = "positive"
    Reviewlist = [ReviewT,Ratings,answer,NameT,Uname]
    totalList.append("ReviewList")
    return render_template('Results.html', Type=ReviewT, Review=Ratings,Pos=answer,Name=NameT,Uname=Uname, all=totalList)
    
@app.route('/hobbies', methods=("GET","POST"))
def hobbies():
    return render_template('hobbies.html')
if __name__=="__main__":
    app.run(debug=True)