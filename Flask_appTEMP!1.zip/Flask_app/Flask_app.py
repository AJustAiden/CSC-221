from flask import Flask
from flask import render_template
app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'Miguel'}
    posts = [
        {
            'author': {'username': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template('index.html', title='Home', user=user, posts=posts)
@app.route('/history')
def history():
    return render_template('history.html', title='Past jobs', user= {'username': 'Miguel'})
@app.route('/daily')
def daily():
    return render_template('daily.html', title='Past jobs', user= {'username': 'Miguel'})
@app.route('/hobbies')
def hobbies():
    return render_template('hobbies.html', title='Past jobs', user= {'username': 'Miguel'})