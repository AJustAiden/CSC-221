#Aiden Allison
#3/21/24
#PRO_1 inheritance
import csv
def main():
    class Product():
        def __init__(self, name, unitprice, ID):
            self.name = name
            self.unitprice = unitprice
            self.ID = ID
        def get_ID(self):
            return self.ID
        def get_name(self):
            return self.name
        def get_unitprice(self):
            return self.unitprice
    class Customer():
        def __init__(self, fname, lname, CusID):
            self.fname = fname
            self.lname = lname
            self.CusID = CusID
        def get_CusID(self):
            return self.CusID
        def get_fname(self):
            return self.fname
        def get_lname(self):
            return self.lname
    class Preminum(Customer):
        def __init__(self, fname, lname, CusID):
            self.fname = fname
            self.lname = lname
            self.CusID = (str(CusID) + "_100")
            super().__init__(fname, lname, CusID)
    with open('customers(1).csv', newline='') as csvfile:
        customerlist = []
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row["Premium"] == "N":
                customer = Customer(row["FirstName"],row["LastName"],row["id"])
                customerlist.append(customer)
            else:
                customer = Preminum(row["FirstName"],row["LastName"],row["id"])
                customerlist.append(customer)
    with open('products(1).csv', newline='') as csvfile:
        prodlist = []
        reader = csv.DictReader(csvfile)
        for row in reader:
            temp = Product(row["ItemDescription"],row["UnitPrice"],row["id"])
            prodlist.append(temp)
        inputid = input("What is your customer ID?")
        for i in customerlist:
            if i.get_CusID() == inputid:
                cname = (i.get_fname())
                lname = (i.get_lname())
                rerun = "yes"
                while rerun != "no":
                    prodid = input("What product ID are you searching for?")
                    if isinstance(i,Preminum) == True:
                        discount =  0.10
                    else:
                        discount = 0
                    for i in prodlist:
                        if i.get_ID() == prodid:
                            pname = (i.get_name())
                            price = (i.get_unitprice())
                            price=float(price.replace("$",""))
                            amountp = int(input("How many do you want to buy?"))
                            price =(amountp * (price)) - (amountp * (price)) * discount
                            print(f"Customer name:{cname} {lname} \nProduct:{pname} \ntotal of product bought:{price}")
                            with open('Orders.txt', "a") as f:
                                f.write(f"\nCustomer name:{cname} {lname} \nProduct:{pname} \ntotal of product bought:{price}")
                    print("File appended")
                    rerun = input("Do you want buy another product?")
if __name__ == "__main__":
        main()
