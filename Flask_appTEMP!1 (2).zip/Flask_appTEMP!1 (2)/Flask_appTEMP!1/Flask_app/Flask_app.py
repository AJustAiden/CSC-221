from flask import *
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', title='Home')
@app.route('/history')
def history():
    return render_template('history.html', title='Past jobs', user= {'username': 'Miguel'})
@app.route('/daily')
def daily():
    return render_template('daily.html', title='Past jobs', user= {'username': 'Miguel'})
@app.route("/Results",methods=["POST"])
def Results():
    ReviewT = request.form['ReviewT']
    NameT = request.form['NameT']
    Ratings = request.form['Ratings']
    Uname = request.form['Uname']
    #Rate_string = Ratings.rstrip(".").split(" ")
    sid_obj = SentimentIntensityAnalyzer()
    sentiment_dict = sid_obj.polarity_scores(Ratings)
    #Slist=[sentiment_dict['neg']*100, "% Negative",sentiment_dict['neu']*100, "% Neutral",sentiment_dict['pos']*100, "% Positive"]
    #for i in range(len(Slist)):
        #if int(Slist[i]) < int(Slist[i-1]):
            #answer = i
    if sentiment_dict['neg']*100 > sentiment_dict['pos']*100:
        answer = "negative"
    else:
        answer = "positive"
    return render_template('Results.html', Type=ReviewT, Review=Ratings,Pos=answer,Name=NameT,Uname=Uname)
    
@app.route('/hobbies', methods=("GET","POST"))
def hobbies():
    return render_template('hobbies.html')
if __name__=="__main__":
    app.run(debug=True)